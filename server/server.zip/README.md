# example-rest-api-fastify-mysql

## How to Install
1. npm install
2. create .env file
```
  SERVER_PORT=3000
  DB_HOST=localhost
  DB_USER=YOUR_DB_USER
  DB_PASSWORD=YOUR_PASSWORD
  DB_NAME=YOUR_DATABASE
  DB_PORT=3306
```
3. node server.js

## Read Detail Article
https://omadijaya.id/nodejs-simple-rest-api-with-fastify-and-mysql/
